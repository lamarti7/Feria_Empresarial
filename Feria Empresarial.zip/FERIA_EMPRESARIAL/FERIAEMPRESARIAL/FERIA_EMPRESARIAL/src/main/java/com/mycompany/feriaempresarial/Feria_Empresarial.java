package com.mycompany.feriaempresarial;

public class Feria_Empresarial {

	private String NOMBRE;
	private String UBICACION;
	private String TEMATICA;
	private String PARTICIPANTES;

	public String REGISTRAR() {
		// TODO - implement FERIA_EMPRESARIAL.REGISTRAR
		throw new UnsupportedOperationException();
	}

	public String INTERACCION() {
		// TODO - implement FERIA_EMPRESARIAL.INTERACCIÓN
		throw new UnsupportedOperationException();
	}

	public String REPORTES() {
		// TODO - implement FERIA_EMPRESARIAL.REPORTES
		throw new UnsupportedOperationException();
	}

	public String getNOMBRE() {
		// TODO - implement FERIA_EMPRESARIAL.getNOMBRE
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param NOMBRE
	 */
	public void setNOMBRE(String NOMBRE) {
		// TODO - implement FERIA_EMPRESARIAL.setNOMBRE
		throw new UnsupportedOperationException();
	}

	public String getUBICACION() {
		// TODO - implement FERIA_EMPRESARIAL.getUBICACION
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param UBICACION
	 */
	public void setUBICACION(String UBICACION) {
		// TODO - implement FERIA_EMPRESARIAL.setUBICACION
		throw new UnsupportedOperationException();
	}

	public String getTEMATICA() {
		// TODO - implement FERIA_EMPRESARIAL.getTEMATICA
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param TEMATICA
	 */
	public void setTEMATICA(String TEMATICA) {
		// TODO - implement FERIA_EMPRESARIAL.setTEMATICA
		throw new UnsupportedOperationException();
	}

	public String getPARTICIPANTES() {
		// TODO - implement FERIA_EMPRESARIAL.getPARTICIPANTES
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param PARTICIPANTES
	 */
	public void setPARTICIPANTES(String PARTICIPANTES) {
		// TODO - implement FERIA_EMPRESARIAL.setPARTICIPANTES
		throw new UnsupportedOperationException();
	}

}